#ifndef MEMORY_HPP
#define MEMORY_HPP

#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include <vector>
#include <algorithm>
#include <sys/wait.h>
#include <errno.h>

class Memory {
private:
    static constexpr const char* GAME_PACKAGE = "com.tencent.ig";
    static int cachedPid;
    static bool hasRootAccess;
    
    /**
     * التحقق من وجود الروت
     */
    static bool CheckRootAccess() {
        // التحقق من وجود ملف su
        if (access("/system/bin/su", F_OK) == 0) return true;
        if (access("/sbin/su", F_OK) == 0) return true;
        if (access("/system/xbin/su", F_OK) == 0) return true;
        if (access("/su/bin/su", F_OK) == 0) return true;
        if (access("/magisk/.core/bin/su", F_OK) == 0) return true;
        if (access("/sbin/.magisk", F_OK) == 0) return true;
        
        return false;
    }
    
    /**
     * طلب صلاحية الروت
     */
    static bool RequestRootAccess() {
        if (hasRootAccess) return true;
        
        // محاولة تنفيذ أمر su
        FILE* fp = popen("su -c 'echo test' 2>/dev/null", "r");
        if (!fp) return false;
        
        char buffer[32];
        bool success = false;
        if (fgets(buffer, sizeof(buffer), fp) != nullptr) {
            if (strstr(buffer, "test") != nullptr) {
                success = true;
            }
        }
        pclose(fp);
        
        if (success) {
            hasRootAccess = true;
        }
        
        return success;
    }
    
public:
    /**
     * الحصول على صلاحية الروت
     */
    static bool EnsureRootAccess() {
        if (hasRootAccess) return true;
        hasRootAccess = CheckRootAccess();
        if (!hasRootAccess) {
            hasRootAccess = RequestRootAccess();
        }
        return hasRootAccess;
    }
    
    /**
     * الحصول على PID اللعبة
     */
    static int GetPid(const char* packageName = GAME_PACKAGE) {
        if (cachedPid > 0) return cachedPid;
        
        char cmd[256];
        snprintf(cmd, sizeof(cmd), "pidof %s 2>/dev/null", packageName);
        FILE* fp = popen(cmd, "r");
        if (!fp) return 0;
        
        int result = 0;
        fscanf(fp, "%d", &result);
        pclose(fp);
        cachedPid = result;
        return cachedPid;
    }
    
    /**
     * الحصول على العنوان الأساسي للمكتبة
     */
    static uintptr_t GetBaseAddress(int pid, const char* library) {
        if (pid <= 0) return 0;
        if (!EnsureRootAccess()) return 0;
        
        char path[256];
        snprintf(path, sizeof(path), "/proc/%d/maps", pid);
        FILE* fp = fopen(path, "r");
        if (!fp) return 0;
        
        char line[512];
        uintptr_t base = 0;
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, library) && strstr(line, "r-xp")) {
                sscanf(line, "%lx", &base);
                break;
            }
        }
        fclose(fp);
        return base;
    }
    
    /**
     * قراءة الذاكرة
     */
    static bool ReadMemory(uintptr_t address, void* buffer, size_t size) {
        if (address == 0 || !buffer || size == 0) return false;
        if (!EnsureRootAccess()) return false;
        
        int currentPid = GetPid();
        if (currentPid == 0) return false;
        
        char path[256];
        snprintf(path, sizeof(path), "/proc/%d/mem", currentPid);
        int fd = open(path, O_RDONLY);
        if (fd < 0) {
            // محاولة استخدام dd
            char cmd[512];
            snprintf(cmd, sizeof(cmd), "su -c 'dd if=/proc/%d/mem bs=1 skip=%lu count=%zu 2>/dev/null'",
                     currentPid, address, size);
            FILE* fp = popen(cmd, "r");
            if (!fp) return false;
            
            size_t bytes = fread(buffer, 1, size, fp);
            pclose(fp);
            return bytes == size;
        }
        
        lseek(fd, address, SEEK_SET);
        ssize_t bytes = read(fd, buffer, size);
        close(fd);
        return bytes == (ssize_t)size;
    }
    
    /**
     * كتابة الذاكرة
     */
    static bool WriteMemory(uintptr_t address, const void* data, size_t size) {
        if (address == 0 || !data || size == 0) return false;
        if (!EnsureRootAccess()) return false;
        
        int currentPid = GetPid();
        if (currentPid == 0) return false;
        
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "su -c 'dd of=/proc/%d/mem bs=1 seek=%lu count=%zu 2>/dev/null'", 
                 currentPid, address, size);
        FILE* fp = popen(cmd, "w");
        if (!fp) return false;
        
        size_t written = fwrite(data, 1, size, fp);
        int status = pclose(fp);
        return written == size && status == 0;
    }
    
    /**
     * قراءة قيمة (قالب)
     */
    template<typename T>
    static T Read(uintptr_t address) {
        T value = T();
        ReadMemory(address, &value, sizeof(T));
        return value;
    }
    
    /**
     * كتابة قيمة (قالب)
     */
    template<typename T>
    static bool Write(uintptr_t address, const T& value) {
        return WriteMemory(address, &value, sizeof(T));
    }
    
    /**
     * قراءة متعددة المستويات
     */
    template<typename T>
    static T ReadMultiLevel(uintptr_t address, const std::vector<int>& offsets) {
        if (!EnsureRootAccess()) return T();
        
        uintptr_t current = address;
        for (int offset : offsets) {
            if (current == 0) return T();
            current = Read<uintptr_t>(current + offset);
        }
        return Read<T>(current);
    }
    
    /**
     * التحقق من تشغيل اللعبة
     */
    static bool IsGameRunning() {
        return GetPid() != 0;
    }
    
    /**
     * التحقق من صلاحية الروت
     */
    static bool HasRoot() {
        return EnsureRootAccess();
    }
};

// ===== تهيئة المتغيرات الثابتة =====
int Memory::cachedPid = 0;
bool Memory::hasRootAccess = false;

#endif //MEMORY_HPP