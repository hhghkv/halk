#include <jni.h>
#include <string>
#include <android/log.h>
#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <sys/wait.h>
#include <errno.h>
#include <thread>
#include <chrono>

#define LOG_TAG "ESP_NATIVE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

#include "Memory.hpp"
#include "Offsets.hpp"
#include "Hacks.h"
#include "Color.h"
#include "items.h"

// ============================================================
// 📌 دوال الروت والذاكرة
// ============================================================

/**
 * التحقق من وجود الروت
 */
bool HasRootAccess() {
    // التحقق من وجود ملف su
    if (access("/system/bin/su", F_OK) == 0) return true;
    if (access("/sbin/su", F_OK) == 0) return true;
    if (access("/system/xbin/su", F_OK) == 0) return true;
    if (access("/su/bin/su", F_OK) == 0) return true;
    if (access("/magisk/.core/bin/su", F_OK) == 0) return true;
    
    // التحقق من وجود Magisk
    if (access("/sbin/.magisk", F_OK) == 0) return true;
    
    return false;
}

/**
 * طلب صلاحية الروت عبر su
 */
bool RequestRootAccess() {
    if (HasRootAccess()) {
        LOGI("✅ Root detected");
        return true;
    }
    
    LOGE("❌ Root not detected, trying to request...");
    
    // محاولة تنفيذ أمر su
    FILE* fp = popen("su -c 'echo test' 2>/dev/null", "r");
    if (!fp) return false;
    
    char buffer[32];
    bool success = false;
    if (fgets(buffer, sizeof(buffer), fp) != nullptr) {
        if (strstr(buffer, "test") != nullptr) {
            success = true;
        }
    }
    pclose(fp);
    
    if (success) {
        LOGI("✅ Root access granted");
        return true;
    }
    
    LOGE("❌ Root access denied");
    return false;
}

/**
 * تنفيذ أمر كـ root
 */
bool ExecuteAsRoot(const char* command) {
    if (!RequestRootAccess()) {
        LOGE("❌ Cannot execute as root: no root access");
        return false;
    }
    
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "su -c '%s' 2>/dev/null", command);
    
    int result = system(cmd);
    return result == 0;
}

/**
 * الحصول على PID اللعبة
 */
int GetGamePid() {
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "pidof com.tencent.ig 2>/dev/null");
    
    FILE* fp = popen(cmd, "r");
    if (!fp) return 0;
    
    int pid = 0;
    fscanf(fp, "%d", &pid);
    pclose(fp);
    return pid;
}

/**
 * الحصول على العنوان الأساسي للمكتبة
 */
uintptr_t GetBaseAddress(int pid, const char* library) {
    if (pid == 0) {
        pid = GetGamePid();
        if (pid == 0) return 0;
    }
    
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (!fp) return 0;
    
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, library) && strstr(line, "r-xp")) {
            sscanf(line, "%lx", &base);
            break;
        }
    }
    fclose(fp);
    return base;
}

/**
 * قراءة الذاكرة باستخدام /proc/[pid]/mem
 */
bool ReadMemory(uintptr_t address, void* buffer, size_t size) {
    if (!RequestRootAccess()) {
        LOGE("❌ Cannot read memory: no root access");
        return false;
    }
    
    int pid = GetGamePid();
    if (pid == 0) {
        LOGE("❌ Game not running");
        return false;
    }
    
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        LOGE("❌ Cannot open mem file: %s", strerror(errno));
        return false;
    }
    
    if (lseek(fd, address, SEEK_SET) == -1) {
        LOGE("❌ Cannot seek to address: %s", strerror(errno));
        close(fd);
        return false;
    }
    
    ssize_t bytes = read(fd, buffer, size);
    close(fd);
    
    if (bytes != (ssize_t)size) {
        LOGE("❌ Cannot read memory: read %zd bytes, expected %zu", bytes, size);
        return false;
    }
    
    return true;
}

/**
 * كتابة الذاكرة
 */
bool WriteMemory(uintptr_t address, const void* data, size_t size) {
    if (!RequestRootAccess()) {
        LOGE("❌ Cannot write memory: no root access");
        return false;
    }
    
    int pid = GetGamePid();
    if (pid == 0) {
        LOGE("❌ Game not running");
        return false;
    }
    
    char cmd[512];
    snprintf(cmd, sizeof(cmd), 
             "su -c 'dd of=/proc/%d/mem bs=1 seek=%lu count=%zu 2>/dev/null'",
             pid, address, size);
    
    FILE* fp = popen(cmd, "w");
    if (!fp) {
        LOGE("❌ Cannot open pipe for writing");
        return false;
    }
    
    size_t written = fwrite(data, 1, size, fp);
    int status = pclose(fp);
    
    if (written != size) {
        LOGE("❌ Cannot write memory: wrote %zu bytes, expected %zu", written, size);
        return false;
    }
    
    if (status != 0) {
        LOGE("❌ Command failed with status %d", status);
        return false;
    }
    
    return true;
}

/**
 * قالب لقراءة الذاكرة
 */
template<typename T>
T Read(uintptr_t address) {
    T value = T();
    ReadMemory(address, &value, sizeof(T));
    return value;
}

/**
 * قالب لكتابة الذاكرة
 */
template<typename T>
bool Write(uintptr_t address, T value) {
    return WriteMemory(address, &value, sizeof(T));
}

// ============================================================
// 📌 تطبيق التعديلات
// ============================================================

/**
 * تطبيق جميع التعديلات
 */
bool ApplyAllPatches() {
    if (!RequestRootAccess()) {
        LOGE("❌ Root access required");
        return false;
    }
    
    int pid = GetGamePid();
    if (pid == 0) {
        LOGE("❌ Game not running");
        return false;
    }
    
    LOGI("✅ Applying patches...");
    
    // الحصول على العناوين الأساسية
    uintptr_t baseUE4 = GetBaseAddress(pid, "libUE4.so");
    uintptr_t baseAnogs = GetBaseAddress(pid, "libanogs.so");
    
    if (baseUE4 == 0) {
        LOGE("❌ libUE4.so not found");
        return false;
    }
    
    LOGI("✅ libUE4.so base: 0x%lx", baseUE4);
    LOGI("✅ libanogs.so base: 0x%lx", baseAnogs);
    
    // ===== تعديلات libUE4.so =====
    if (baseUE4 != 0) {
        // تعطيل تقارير مكافحة الغش
        Write<uint32_t>(baseUE4 + 0x2A2E2C0, 0xFFFFFFFF);
        Write<uint32_t>(baseUE4 + 0x2A2E500, 0xFFFFFFFF);
        
        // تعطيل فحص الروت
        Write<uint32_t>(baseUE4 + 0x2A2F100, 0xFFFFFFFF);
        Write<uint32_t>(baseUE4 + 0x2A2F200, 0xFFFFFFFF);
        
        // تعطيل فحص الـ NoRecoil
        Write<uint32_t>(baseUE4 + 0x2A2E800, 0xFFFFFFFF);
        
        // تعطيل فحص السيرفر
        Write<uint32_t>(baseUE4 + 0x2A2F300, 0xFFFFFFFF);
        
        LOGI("✅ UE4 patches applied");
    }
    
    // ===== تعديلات libanogs.so =====
    if (baseAnogs != 0) {
        Write<uint32_t>(baseAnogs + 0x12208C, 0xFFFFFFFF);
        Write<uint32_t>(baseAnogs + 0x123A94, 0xFFFFFFFF);
        Write<uint32_t>(baseAnogs + 0x1245A0, 0xFFFFFFFF);
        
        LOGI("✅ anogs patches applied");
    }
    
    LOGI("✅ All patches applied successfully");
    return true;
}

// ============================================================
// 📌 دوال JNI المصدرة
// ============================================================

extern "C" {

/**
 * التحقق من صلاحية الروت
 */
JNIEXPORT jboolean JNICALL
Java_com_example_esp_NativeUtils_requestRoot(JNIEnv* env, jobject thiz) {
    bool hasRoot = HasRootAccess();
    if (!hasRoot) {
        hasRoot = RequestRootAccess();
    }
    
    LOGI("Root access: %s", hasRoot ? "GRANTED" : "DENIED");
    return hasRoot ? JNI_TRUE : JNI_FALSE;
}

/**
 * تطبيق جميع التعديلات
 */
JNIEXPORT jboolean JNICALL
Java_com_example_esp_NativeUtils_applyAllPatches(JNIEnv* env, jobject thiz) {
    return ApplyAllPatches() ? JNI_TRUE : JNI_FALSE;
}

/**
 * قراءة قيمة Long من الذاكرة
 */
JNIEXPORT jlong JNICALL
Java_com_example_esp_NativeUtils_readLong(JNIEnv* env, jobject thiz, jlong address) {
    if (address == 0) return 0;
    if (!RequestRootAccess()) return 0;
    return (jlong)Read<long>(address);
}

/**
 * كتابة قيمة Long في الذاكرة
 */
JNIEXPORT void JNICALL
Java_com_example_esp_NativeUtils_writeLong(JNIEnv* env, jobject thiz, jlong address, jlong value) {
    if (address == 0) return;
    if (!RequestRootAccess()) return;
    Write<long>(address, value);
}

/**
 * قراءة قيمة Int من الذاكرة
 */
JNIEXPORT jint JNICALL
Java_com_example_esp_NativeUtils_readInt(JNIEnv* env, jobject thiz, jlong address) {
    if (address == 0) return 0;
    if (!RequestRootAccess()) return 0;
    return (jint)Read<int>(address);
}

/**
 * كتابة قيمة Int في الذاكرة
 */
JNIEXPORT void JNICALL
Java_com_example_esp_NativeUtils_writeInt(JNIEnv* env, jobject thiz, jlong address, jint value) {
    if (address == 0) return;
    if (!RequestRootAccess()) return;
    Write<int>(address, value);
}

/**
 * قراءة قيمة Float من الذاكرة
 */
JNIEXPORT jfloat JNICALL
Java_com_example_esp_NativeUtils_readFloat(JNIEnv* env, jobject thiz, jlong address) {
    if (address == 0) return 0.0f;
    if (!RequestRootAccess()) return 0.0f;
    return (jfloat)Read<float>(address);
}

/**
 * كتابة قيمة Float في الذاكرة
 */
JNIEXPORT void JNICALL
Java_com_example_esp_NativeUtils_writeFloat(JNIEnv* env, jobject thiz, jlong address, jfloat value) {
    if (address == 0) return;
    if (!RequestRootAccess()) return;
    Write<float>(address, value);
}

/**
 * التحقق من وجود الروت
 */
JNIEXPORT jboolean JNICALL
Java_com_example_esp_NativeUtils_isRootGiven(JNIEnv* env, jobject thiz) {
    return HasRootAccess() ? JNI_TRUE : JNI_FALSE;
}

/**
 * التحقق من تشغيل اللعبة
 */
JNIEXPORT jboolean JNICALL
Java_com_example_esp_NativeUtils_isGameRunning(JNIEnv* env, jobject thiz) {
    int pid = GetGamePid();
    LOGI("Game PID: %d", pid);
    return pid != 0 ? JNI_TRUE : JNI_FALSE;
}

/**
 * الحصول على PID اللعبة
 */
JNIEXPORT jint JNICALL
Java_com_example_esp_NativeUtils_getGamePid(JNIEnv* env, jobject thiz) {
    int pid = GetGamePid();
    LOGI("Game PID: %d", pid);
    return (jint)pid;
}

/**
 * الحصول على العنوان الأساسي لـ libUE4.so
 */
JNIEXPORT jlong JNICALL
Java_com_example_esp_NativeUtils_getUE4Base(JNIEnv* env, jobject thiz) {
    int pid = GetGamePid();
    if (pid == 0) return 0;
    
    uintptr_t base = GetBaseAddress(pid, "libUE4.so");
    LOGI("✅ libUE4.so base: 0x%lx", base);
    return (jlong)base;
}

/**
 * اختبار قراءة الذاكرة
 */
JNIEXPORT jboolean JNICALL
Java_com_example_esp_NativeUtils_testMemoryRead(JNIEnv* env, jobject thiz, jlong address) {
    if (address == 0) return JNI_FALSE;
    if (!RequestRootAccess()) return JNI_FALSE;
    
    // محاولة قراءة 4 بايت
    uint32_t value = 0;
    if (ReadMemory(address, &value, sizeof(uint32_t))) {
        LOGI("✅ Memory read successful: 0x%x at 0x%lx", value, address);
        return JNI_TRUE;
    }
    
    LOGE("❌ Memory read failed");
    return JNI_FALSE;
}

/**
 * الحصول على GWorld
 */
JNIEXPORT jlong JNICALL
Java_com_example_esp_NativeUtils_getGWorld(JNIEnv* env, jobject thiz) {
    int pid = GetGamePid();
    if (pid == 0) {
        LOGE("❌ Game not running");
        return 0;
    }
    
    uintptr_t base = GetBaseAddress(pid, "libUE4.so");
    if (base == 0) {
        LOGE("❌ libUE4.so not found");
        return 0;
    }
    
    uintptr_t gWorld = base + 0xE498300; // GWorld offset
    LOGI("✅ GWorld: 0x%lx", gWorld);
    return (jlong)gWorld;
}

} // extern "C"