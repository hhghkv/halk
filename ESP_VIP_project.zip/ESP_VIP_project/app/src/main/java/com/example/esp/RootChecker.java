package com.example.esp;

import java.io.File;

public final class RootChecker {
    private RootChecker() {}
    public static boolean isRootAvailable() {
        String[] paths = {"/system/bin/su", "/system/xbin/su", "/sbin/su"};
        for (String path : paths) if (new File(path).exists()) return true;
        return false;
    }
}
