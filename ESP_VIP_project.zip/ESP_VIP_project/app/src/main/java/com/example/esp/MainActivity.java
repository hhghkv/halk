package com.example.esp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivity(intent);
        }

        Button btnStart = findViewById(R.id.btn_start);
        btnStart.setOnClickListener(v -> {
            startService(new Intent(this, FloatingActivity.class));
            Toast.makeText(this, "ESP Started!", Toast.LENGTH_SHORT).show();
        });

        Button btnSettings = findViewById(R.id.btn_settings);
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        Button btnStop = findViewById(R.id.btn_stop);
        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingActivity.class));
            Toast.makeText(this, "ESP Stopped!", Toast.LENGTH_SHORT).show();
        });
    }
}
