#ifndef KONTOL_ESP_IMPORTANT_CLASS_H
#define KONTOL_ESP_IMPORTANT_CLASS_H

#include <string>
#include <array>
#include <cmath>
#include <algorithm>

// ===== كلاس اللون =====
class Color {
public:
    int r, g, b, a;

    // المُنشئات
    Color() : r(0), g(0), b(0), a(255) {}
    Color(int r, int g, int b, int a = 255) : r(r), g(g), b(b), a(a) {}
    Color(float r, float g, float b, float a = 255.0f) 
        : r((int)r), g((int)g), b((int)b), a((int)a) {}

    // دوال ثابتة للألوان الشائعة
    static Color White(int alpha = 255) { return Color(255, 255, 255, alpha); }
    static Color Black(int alpha = 255) { return Color(0, 0, 0, alpha); }
    static Color Red(int alpha = 255) { return Color(255, 0, 0, alpha); }
    static Color Green(int alpha = 255) { return Color(0, 255, 0, alpha); }
    static Color Blue(int alpha = 255) { return Color(0, 0, 255, alpha); }
    static Color Yellow(int alpha = 255) { return Color(255, 255, 0, alpha); }
    static Color Orange(int alpha = 255) { return Color(255, 165, 0, alpha); }
    static Color Cyan(int alpha = 255) { return Color(0, 255, 255, alpha); }
    static Color Magenta(int alpha = 255) { return Color(255, 0, 255, alpha); }
    static Color Purple(int alpha = 255) { return Color(128, 0, 128, alpha); }
    static Color Gray(int alpha = 255) { return Color(128, 128, 128, alpha); }
    static Color Pink(int alpha = 255) { return Color(255, 192, 203, alpha); }
    static Color Brown(int alpha = 255) { return Color(165, 42, 42, alpha); }
    static Color Lime(int alpha = 255) { return Color(50, 205, 50, alpha); }
    static Color Gold(int alpha = 255) { return Color(255, 215, 0, alpha); }
    static Color SkyBlue(int alpha = 255) { return Color(135, 206, 235, alpha); }
    
    // دمج لونين
    static Color Blend(const Color& c1, const Color& c2, float t) {
        t = std::max(0.0f, std::min(1.0f, t));
        return Color(
            (int)(c1.r + (c2.r - c1.r) * t),
            (int)(c1.g + (c2.g - c1.g) * t),
            (int)(c1.b + (c2.b - c1.b) * t),
            (int)(c1.a + (c2.a - c1.a) * t)
        );
    }
};

// ===== هيكل Vector2 =====
struct Vec2 {
    float x, y;

    Vec2() : x(0), y(0) {}
    Vec2(float x, float y) : x(x), y(y) {}
    
    static Vec2 Zero() { return Vec2(0.0f, 0.0f); }
    static Vec2 One() { return Vec2(1.0f, 1.0f); }
    
    float Length() const { return sqrt(x*x + y*y); }
    float SqrLength() const { return x*x + y*y; }
    Vec2 Normalized() const { float len = Length(); return len > 0 ? Vec2(x/len, y/len) : Vec2(); }
    
    Vec2 operator+(const Vec2& v) const { return Vec2(x + v.x, y + v.y); }
    Vec2 operator-(const Vec2& v) const { return Vec2(x - v.x, y - v.y); }
    Vec2 operator*(float s) const { return Vec2(x * s, y * s); }
    Vec2 operator/(float s) const { return Vec2(x / s, y / s); }
    Vec2& operator+=(const Vec2& v) { x += v.x; y += v.y; return *this; }
    Vec2& operator-=(const Vec2& v) { x -= v.x; y -= v.y; return *this; }
    bool operator==(const Vec2& v) const { return x == v.x && y == v.y; }
    bool operator!=(const Vec2& v) const { return !(*this == v); }
};

// ===== هيكل Vector3 =====
struct Vec3 {
    float x, y, z;

    Vec3() : x(0), y(0), z(0) {}
    Vec3(float x, float y, float z) : x(x), y(y), z(z) {}
    
    static Vec3 Zero() { return Vec3(0, 0, 0); }
    static Vec3 One() { return Vec3(1, 1, 1); }
    
    float Length() const { return sqrt(x*x + y*y + z*z); }
    float SqrLength() const { return x*x + y*y + z*z; }
    Vec3 Normalized() const { float len = Length(); return len > 0 ? Vec3(x/len, y/len, z/len) : Vec3(); }
    
    Vec3 operator+(const Vec3& v) const { return Vec3(x + v.x, y + v.y, z + v.z); }
    Vec3 operator-(const Vec3& v) const { return Vec3(x - v.x, y - v.y, z - v.z); }
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
    Vec3 operator/(float s) const { return Vec3(x / s, y / s, z / s); }
};

// ===== هيكل Rect =====
struct Rect {
    float x, y, width, height;

    Rect() : x(0), y(0), width(0), height(0) {}
    Rect(float x, float y, float width, float height) 
        : x(x), y(y), width(width), height(height) {}
    
    bool Contains(const Vec2& point) const {
        return point.x >= x && point.x <= x + width &&
               point.y >= y && point.y <= y + height;
    }
    
    bool Intersects(const Rect& other) const {
        return x < other.x + other.width &&
               x + width > other.x &&
               y < other.y + other.height &&
               y + height > other.y;
    }
};

#endif //KONTOL_ESP_IMPORTANT_CLASS_H