#ifndef ZEROPC_DEV_IMPORTANT_IMPORT_H
#define ZEROPC_DEV_IMPORTANT_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <cmath>

// ===== Booleans =====
extern bool isHideItem;
extern bool is360Alertv2;
extern bool isSkeleton;
extern bool isPlayerHead;
extern bool isPlayerBox;
extern bool isKnockedPlayerHealth;
extern bool isLootBox;
extern bool isPlayerLine;
extern bool isPlayerHealth;
extern bool isPlayerName;
extern bool isPlayerDistance;
extern bool isPlayerWeapon;
extern bool isPlayerWeaponIcon;
extern bool isGrenadeWarning;
extern bool enemycountv1;
extern bool enemycountv2;
extern bool isPlayerUID;
extern bool isNation;
extern int healthStyle;
extern int playerCounterStyle;

// ===== دالة حساب حجم النص =====
inline int StrLen(const char* str) {
    int len = 0;
    while (str[len] != '\0') len++;
    return len;
}

// ===== دوال مساعدة =====

/**
 * التحقق من وجود ملف
 */
inline bool FileExists(const char* path) {
    return access(path, F_OK) == 0;
}

/**
 * الحصول على حجم الملف
 */
inline long GetFileSize(const char* path) {
    FILE* fp = fopen(path, "r");
    if (!fp) return -1;
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fclose(fp);
    return size;
}

#endif //ZEROPC_DEV_IMPORTANT_IMPORT_H