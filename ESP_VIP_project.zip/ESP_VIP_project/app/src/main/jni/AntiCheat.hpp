#ifndef ANTICHEAT_HPP
#define ANTICHEAT_HPP

#include <vector>
#include <string>
#include <cstdint>
#include "Memory.hpp"

class AntiCheat {
public:
    struct Patch {
        std::string library;
        uintptr_t offset;
        std::vector<uint8_t> original;
        std::vector<uint8_t> patch;
        bool applied;
    };
    
    /**
     * الحصول على قائمة التعديلات
     */
    static std::vector<Patch> GetPatches() {
        return {
            {"libanogs.so", 0x12208C, {}, {0xC0, 0x03, 0x5F, 0xD6}},
            {"libanogs.so", 0x123A94, {}, {0xC0, 0x03, 0x5F, 0xD6}},
            {"libanogs.so", 0x1245A0, {}, {0x00, 0x00, 0x80, 0x52}},
            {"libUE4.so", 0x2A2E2C0, {}, {0xC0, 0x03, 0x5F, 0xD6}},
            {"libUE4.so", 0x2A2E500, {}, {0xC0, 0x03, 0x5F, 0xD6}},
            {"libUE4.so", 0x2A2F100, {}, {0x00, 0x00, 0x80, 0x52}},
        };
    }
    
    /**
     * تطبيق جميع التعديلات
     */
    static bool ApplyAllPatches() {
        if (!Memory::EnsureRootAccess()) {
            return false;
        }
        
        int pid = Memory::GetPid();
        if (pid == 0) return false;
        
        auto patches = GetPatches();
        for (auto& patch : patches) {
            uintptr_t base = Memory::GetBaseAddress(pid, patch.library.c_str());
            if (base == 0) continue;
            
            uintptr_t address = base + patch.offset;
            
            // قراءة القيمة الأصلية
            uint8_t original[8];
            if (Memory::ReadMemory(address, original, patch.patch.size())) {
                patch.original.assign(original, original + patch.patch.size());
            }
            
            // تطبيق التعديل
            if (Memory::WriteMemory(address, patch.patch.data(), patch.patch.size())) {
                patch.applied = true;
            }
        }
        
        return true;
    }
    
    /**
     * استعادة التعديلات
     */
    static bool RestoreAllPatches() {
        if (!Memory::EnsureRootAccess()) {
            return false;
        }
        
        auto patches = GetPatches();
        for (auto& patch : patches) {
            if (!patch.applied || patch.original.empty()) continue;
            
            int pid = Memory::GetPid();
            if (pid == 0) continue;
            
            uintptr_t base = Memory::GetBaseAddress(pid, patch.library.c_str());
            if (base == 0) continue;
            
            uintptr_t address = base + patch.offset;
            Memory::WriteMemory(address, patch.original.data(), patch.original.size());
            patch.applied = false;
        }
        
        return true;
    }
};

#endif