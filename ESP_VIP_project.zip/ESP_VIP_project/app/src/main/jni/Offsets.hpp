#ifndef OFFSETS_HPP
#define OFFSETS_HPP

#include <cstdint>

namespace Offsets {

    const char* LIB_ANOGS = "libanogs.so";
    const char* LIB_UE4 = "libUE4.so";
    const char* LIB_TDATA = "libTDataMaster.so";
    const char* LIB_GCLOUD = "libgcloudcore.so";
    const char* LIB_CRASH = "libCrashSight.so";

    namespace anogs {
        const uintptr_t GetReportData = 0x12208C;
        const uintptr_t DelReportData = 0x123A94;
        const uintptr_t Ioctl = 0x1245A0;
        const uintptr_t OnPause = 0x11E8A4;
        const uintptr_t OnResume = 0x11E9B8;
        const uintptr_t OnRecvData = 0x1251F8;
    }

    namespace ue4 {
        const uintptr_t GWorld = 0xE498300;
        const uintptr_t GNames = 0xE49D6A0;
        const uintptr_t EntityList = 0xE49C760;
        const uintptr_t PlayerName = 0xA88;
        const uintptr_t Health = 0x3C8;
        const uintptr_t Position = 0x150;
        const uintptr_t IsBot = 0x4F8;
        const uintptr_t TeamId = 0x5A0;
        const uintptr_t Weapon = 0x6C0;
        const uintptr_t Distance = 0x7E0;
        const uintptr_t Head = 0x7F0;
        const uintptr_t Back = 0x800;
        const uintptr_t State = 0x8E0;
        const uintptr_t GrenadeWarning = 0x9A0;
        const uintptr_t ReportGameSetting = 0x2A2E2C0;
        const uintptr_t ReportCharacter = 0x2A2E500;
        const uintptr_t CheckRoot = 0x2A2F100;
        const uintptr_t CheckMagisk = 0x2A2F200;
        const uintptr_t VerifyNoRecoil = 0x2A2E800;
        const uintptr_t ServerCheckClient = 0x2A2F300;
        const uintptr_t AntiCheatComp = 0x2A2F800;
    }

    namespace tdm {
        const uintptr_t ReportEvent = 0xCE870;
        const uintptr_t ReportBinary = 0xCE950;
        const uintptr_t HTTPReport = 0xCEA20;
        const uintptr_t EnableReport = 0xCE7F0;
    }

    namespace gcloud {
        const uintptr_t AccountLogin = 0x58B1C;
        const uintptr_t RealnameAuth = 0x58C40;
        const uintptr_t SetAuthType = 0x58D60;
        const uintptr_t EncryptSend = 0x58E80;
    }

    namespace crash {
        const uintptr_t ReportCrash = 0x63EA6;
        const uintptr_t ReportException = 0x63FB0;
        const uintptr_t ReportError = 0x640C0;
    }

}

#endif
