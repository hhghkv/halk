package com.example.esp;

public class MemoryReader {

    public static int readInt(long address) {
        return (int) NativeUtils.readLong(address);
    }

    public static float readFloat(long address) {
        return Float.intBitsToFloat((int) NativeUtils.readLong(address));
    }

    public static String readString(long address, int length) {
        byte[] buffer = new byte[length];
        for (int i = 0; i < length; i++) {
            buffer[i] = (byte) NativeUtils.readLong(address + i);
        }
        return new String(buffer).trim();
    }

    public static void writeInt(long address, int value) {
        NativeUtils.writeLong(address, value);
    }

    public static void writeFloat(long address, float value) {
        NativeUtils.writeLong(address, Float.floatToIntBits(value));
    }

    public static long readLong(long address) {
        return NativeUtils.readLong(address);
    }

    public static void writeLong(long address, long value) {
        NativeUtils.writeLong(address, value);
    }
}
