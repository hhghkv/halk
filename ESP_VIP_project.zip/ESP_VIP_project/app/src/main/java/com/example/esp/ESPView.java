package com.example.esp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class ESPView extends View {

    private Paint paint;
    public static int sleepTime = 33;

    public ESPView(Context context) {
        super(context);
        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4);
    }

    public static void ChangeFps(int fps) {
        sleepTime = 1000 / fps;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRect(100, 100, 300, 400, paint);
        canvas.drawRect(400, 200, 600, 500, paint);
        canvas.drawRect(700, 150, 900, 450, paint);
        postInvalidateDelayed(sleepTime);
    }
}
