package com.example.esp;

import android.content.Context;
import android.content.pm.PackageManager;

public final class GameHelper {
    public static final String GAME_PACKAGE = "com.tencent.ig";
    private GameHelper() {}

    public static boolean isGameInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(GAME_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
