package com.example.esp;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class NativeUtils {

    static {
        System.loadLibrary("native-lib");
    }

    // دوال JNI
    public static native long getGWorld();
    public static native boolean applyAllPatches();
    public static native long readLong(long address);
    public static native void writeLong(long address, long value);
    public static native int getGamePid();

    // ✅ التحقق من الروت بشكل صحيح (مع طلب الصلاحيات)
    public static boolean isRootGiven() {
        try {
            Process process = Runtime.getRuntime().exec("su -c echo test");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String output = reader.readLine();
            process.waitFor();
            return output != null && output.equals("test");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ التحقق من تشغيل اللعبة
    public static boolean isGameRunning() {
        try {
            Process process = Runtime.getRuntime().exec("pidof com.tencent.ig");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            return line != null && !line.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }
}
