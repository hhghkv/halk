#include <cstdint>

namespace esp_demo {
std::uint32_t VersionCode() { return 1; }
}
