#ifndef BETA_ESP_IMPORTANT_COLOR_H
#define BETA_ESP_IMPORTANT_COLOR_H

#include "class.h"

// ===== دوال الألوان =====

/**
 * الحصول على لون حسب معرف الفريق
 * @param TeamID: معرف الفريق (1-1000)
 * @param alpha: الشفافية (0-255)
 * @return: كائن Color
 */
inline Color _clrID(int TeamID, int alpha) {
    // استخدام جدول ألوان محسّن مع توزيع أفضل للألوان
    static const Color teamColors[] = {
        Color(220, 20, 60),     // 1: Crimson
        Color(178, 34, 34),     // 2: Firebrick
        Color(255, 20, 147),    // 3: DeepPink
        Color(199, 21, 133),    // 4: MediumVioletRed
        Color(255, 69, 0),      // 5: OrangeRed
        Color(255, 140, 0),     // 6: DarkOrange
        Color(255, 215, 0),     // 7: Gold
        Color(255, 0, 255),     // 8: Magenta
        Color(138, 43, 226),    // 9: BlueViolet
        Color(128, 0, 128),     // 10: Purple
        Color(75, 0, 130),      // 11: Indigo
        Color(0, 128, 0),       // 12: Green
        Color(0, 100, 0),       // 13: DarkGreen
        Color(32, 178, 170),    // 14: LightSeaGreen
        Color(0, 139, 139),     // 15: DarkCyan
        Color(0, 206, 209),     // 16: DarkTurquoise
        Color(70, 130, 180),    // 17: SteelBlue
        Color(0, 191, 255),     // 18: DeepSkyBlue
        Color(30, 144, 255),    // 19: DodgerBlue
        Color(0, 0, 139),       // 20: DarkBlue
    };
    
    // دورة الألوان: استخدام باقي القسمة للحصول على لون فريد لكل فريق
    int index = (TeamID - 1) % (sizeof(teamColors) / sizeof(teamColors[0]));
    Color baseColor = teamColors[index];
    
    // إضافة لمعان للفرق العالية
    if (TeamID > 100) {
        float brightness = 1.0f + (TeamID - 100) / 1000.0f;
        return Color(
            std::min(255, (int)(baseColor.r * brightness)),
            std::min(255, (int)(baseColor.g * brightness)),
            std::min(255, (int)(baseColor.b * brightness)),
            alpha
        );
    }
    
    return Color(baseColor.r, baseColor.g, baseColor.b, alpha);
}

/**
 * الحصول على لون حسب المسافة (محسّن)
 */
inline Color GetColorByDistance(float distance, int alpha = 255) {
    if (distance < 150.0f)
        return Color::Red(alpha);
    else if (distance < 300.0f)
        return Color::Orange(alpha);
    else if (distance < 600.0f)
        return Color::Yellow(alpha);
    else
        return Color::Green(alpha);
}

#endif //BETA_ESP_IMPORTANT_COLOR_H