ESP VIP - project assembled from the source files provided in the conversation.

Build configuration supplied:
- Android Gradle Plugin: 8.1.2
- Gradle wrapper distribution: 8.10.2
- compileSdk: 33
- minSdk: 26
- targetSdk: 33
- ABI: arm64-v8a
- C++ standard: C++17
- CMake minimum: 3.18.1

Note: this archive preserves the supplied project structure/code rather than claiming it has been built successfully on the target Termux device.
