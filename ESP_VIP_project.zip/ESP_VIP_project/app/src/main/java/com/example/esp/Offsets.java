package com.example.esp;

/** UI/demo constants kept separate from native offsets. */
public final class Offsets {
    private Offsets() {}
    public static final int DEMO_BOX_COUNT = 3;
    public static final int DEFAULT_FPS = 30;
}
