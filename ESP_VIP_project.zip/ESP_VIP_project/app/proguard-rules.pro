-dontobfuscate
-dontoptimize
-dontshrink
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep public class * extends android.app.Service
-keep public class * extends android.app.Activity
-dontwarn javax.**
-dontwarn java.awt.**
