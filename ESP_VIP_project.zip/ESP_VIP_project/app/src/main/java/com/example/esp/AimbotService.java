package com.example.esp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Placeholder for the UI feature only. No automated targeting or game-memory
 * manipulation is performed in this demo project.
 */
public class AimbotService extends Service {
    @Override public IBinder onBind(Intent intent) { return null; }
}
