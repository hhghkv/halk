#ifndef BETA_ESP_IMPORTANT_HACKS_H
#define BETA_ESP_IMPORTANT_HACKS_H

#include "socket.h"
#include "Color.h"
#include "items.h"
#include "rLogin/Login.h"
#include "Vector3.hpp"
#include "timer.h"
#include "Memory.hpp"
#include "import.h"

// ===== الثوابت =====
constexpr float MIN_MAGIC_NUMBER = 0.1f;
constexpr float NEAR_DISTANCE = 150.0f;
constexpr float FAR_DISTANCE = 300.0f;
constexpr float VERY_FAR_DISTANCE = 600.0f;
constexpr float BASE_SCREEN_HEIGHT = 1080.0f;
constexpr float RADAR_SIZE = 150.0f;

// ===== المتغيرات العامة =====
Timer FPSLimiter;
Color enemyColor, edgeColor, boxColor, alertColor, teamColor;
Color distanceColor, healthColor, textColor, grenadeColor, indicatorColor;
float screenWidth, screenHeight, magicNumber, scale, skeletonSize;
int botCount = 0, playerCount = 0;

// ===== الإعدادات =====
Options options {
    1,          // aimBullet
    -1,         // openState
    -1,         // aimT
    3,          // tracingStatus
    false,      // showName
    false,      // showBox
    1,          // 
    false,      // showLine
    200,        // aimingRange
    200,        // touchSize
    700,        // touchX
    19,         // touchY
    19,         // 
    -1,         // 
    false       // 
};

OtherFeature otherFeature {
    false, false, false, false, false, false
};

Response response;
Request request;
char extraBuffer[30];
char textBuffer[100];

// ===== دوال مساعدة =====

/**
 * الحصول على لون حسب المسافة
 */
inline Color GetDistanceColor(float distance, int alpha = 255) {
    if (distance < NEAR_DISTANCE)
        return Color::Red(alpha);
    else if (distance < FAR_DISTANCE)
        return Color::Orange(alpha);
    else if (distance < VERY_FAR_DISTANCE)
        return Color::Yellow(alpha);
    else
        return Color::Green(alpha);
}

/**
 * التحقق من وجود اللاعب في المنتصف
 */
inline bool IsPlayerInCenter(float playerX, float playerY, float top, float bottom,
                             float screenWidth, float screenHeight) {
    float centerX = screenWidth / 2.0f;
    float centerY = screenHeight / 2.0f;
    float marginX = screenWidth * 0.1f;
    float marginY = screenHeight * 0.1f;
    
    return (playerX > centerX - marginX && playerX < centerX + marginX &&
            playerY > centerY - marginY && playerY < centerY + marginY);
}

/**
 * حساب موقع الرادار
 */
inline Vec2 CalculateRadarPosition(const Vec2& location, const Vec2& center, float radius) {
    Vec2 direction = location - center;
    float dist = sqrt(direction.x * direction.x + direction.y * direction.y);
    if (dist < 0.001f) return center;
    
    Vec2 normalized = direction / dist;
    float radarDistance = std::min(dist, radius);
    return center + normalized * radarDistance;
}

// ===== دوال الرسم =====

/**
 * رسم الرادار
 */
inline void DrawRadar(ESP& canvas, const Vec2& playerLocation, const Vec2& radarCenter,
                      float radarSize, const Color& color, int teamID) {
    canvas.DrawFillCircle(Color::Black(35), radarCenter, radarSize + (radarSize / 10.0f), 0.5f);
    canvas.DrawCircle(Color::White(255), radarCenter, radarSize + (radarSize / 10.0f), 1.0f);
    
    canvas.DrawFilledRoundRect(
        Color::White(255),
        {radarCenter.x - radarSize / 25.0f, radarCenter.y - radarSize / 25.0f},
        {radarCenter.x + radarSize / 25.0f, radarCenter.y + radarSize / 25.0f}
    );
    
    Vec2 radarPos = CalculateRadarPosition(playerLocation, radarCenter, radarSize);
    canvas.DrawFillCircle(Color(color.r, color.g, color.b, 255), radarPos, radarSize / 10.0f, 0.5f);
    
    if (isPlayerName) {
        canvas.DrawText(Color::White(255), std::to_string(teamID).c_str(), radarPos, radarSize / 10.0f);
    }
}

/**
 * رسم معلومات اللاعب
 */
inline void DrawPlayerInfo(ESP& canvas, const PlayerData& player, const Vec2& position,
                           float textSize, bool isBot, float distance) {
    // خلفية الاسم
    canvas.DrawFilledName(Color(0, 0, 0, 100),
        Vec2(position.x - 40.0f, position.y - textSize - 5.0f),
        Vec2(position.x + 40.0f, position.y + 5.0f));
    
    // عرض الاسم
    if (isBot) {
        canvas.DrawText(Color::White(255), "البوت",
            Vec2(position.x, position.y - textSize/2.0f),
            textSize * 0.8f);
    } else {
        std::string playerName(reinterpret_cast<const char*>(player.PlayerNameByte), 15);
        canvas.DrawName(Color::White(255), playerName.c_str(),
            Vec2(position.x, position.y - textSize/2.0f),
            textSize * 0.8f);
    }
    
    // عرض رقم الفريق
    canvas.DrawTeamID(Color::White(255), player.TeamID,
        Vec2(position.x - 30.0f, position.y - textSize/2.0f),
        textSize * 0.6f);
    
    // عرض المسافة
    char distanceText[20];
    sprintf(distanceText, "%.0f", distance);
    canvas.DrawText(Color::White(255), distanceText,
        Vec2(position.x + 30.0f, position.y - textSize/2.0f),
        textSize * 0.6f);
}

// ===== الدالة الرئيسية =====
void DrawESP(ESP& esp, int screenWidth, int screenHeight) {
    // التحقق من صلاحية الروت
    if (!Memory::EnsureRootAccess()) {
        esp.DrawText(Color::Red(255), "ROOT REQUIRED", 
                     Vec2(screenWidth/2 - 100, screenHeight/2), 30);
        return;
    }
    
    // التحقق من تشغيل اللعبة
    if (!Memory::IsGameRunning()) {
        esp.DrawText(Color::Red(255), "GAME NOT RUNNING", 
                     Vec2(screenWidth/2 - 100, screenHeight/2), 30);
        return;
    }
    
    // ===== إعداد الطلب =====
    request.radarPos = {screenWidth / 4.0f, screenHeight / 4.0f};
    request.radarSize = RADAR_SIZE;
    request.ScreenHeight = screenHeight;
    request.ScreenWidth = screenWidth;
    request.options = options;
    request.otherFeature = otherFeature;
    request.Mode = InitMode;
    
    // ===== إرسال واستقبال البيانات =====
    botCount = 0;
    playerCount = 0;
    memset(&response, 0, sizeof(response));
    
    if (!send((void*)&request, sizeof(request))) {
        esp.DrawText(Color::Red(255), "SOCKET ERROR", 
                     Vec2(screenWidth/2 - 100, screenHeight/2), 30);
        return;
    }
    
    receive((void*)&response);
    
    if (!response.Success) {
        esp.DrawText(Color::Yellow(255), "WAITING FOR DATA...", 
                     Vec2(screenWidth/2 - 100, screenHeight/2), 30);
        return;
    }
    
    // ===== إعداد المتغيرات =====
    float scaleY = screenHeight / BASE_SCREEN_HEIGHT;
    scale = screenHeight / BASE_SCREEN_HEIGHT;
    skeletonSize = scale * 1.5f;
    float boxLineSize = scaleY * 2.0f;
    float textSize = screenHeight / 50.0f;
    Vec2 screenSize(screenWidth, screenHeight);
    float fov = response.fov > 0 ? response.fov : 1.0f;
    
    // ===== رسم الرادار =====
    esp.DrawFillCircle(Color::Black(35), request.radarPos, 
                       request.radarSize + (request.radarSize / 10.0f), 0.5f);
    esp.DrawCircle(Color::White(255), request.radarPos, 
                   request.radarSize + (request.radarSize / 10.0f), 1.0f);
    
    // ===== معالجة اللاعبين =====
    for (int i = 0; i < response.PlayerCount; i++) {
        PlayerData& player = response.Players[i];
        
        float distance = player.Distance;
        float magicNumber = std::max(distance * fov, MIN_MAGIC_NUMBER);
        float boxWidth = (screenWidth / 6.0f) / magicNumber;
        float verticalOffset = (screenWidth / 1.38f) / magicNumber;
        float top = player.HeadLocation.y - verticalOffset + (screenWidth / 1.7f) / magicNumber;
        float bottom = player.Bone.lAn.y + verticalOffset - (screenWidth / 1.7f) / magicNumber;
        
        Color distanceColor = GetDistanceColor(distance);
        Color teamColor = _clrID(player.TeamID, 150);
        Color alertColor = _clrID(player.TeamID, 80);
        Color boxColor = _clrID(player.TeamID, 200);
        
        if (player.isBot) {
            botCount++;
            boxColor = Color::White(255);
        } else {
            playerCount++;
        }
        
        bool inCenter = IsPlayerInCenter(player.HeadLocation.x, player.HeadLocation.y,
                                        top, bottom, screenWidth, screenHeight);
        if (inCenter) {
            boxColor = Color::Green(255);
        }
        
        // رسم الرادار
        DrawRadar(esp, player.RadarLocation, request.radarPos, 
                  request.radarSize, teamColor, player.TeamID);
        
        // التحقق من وجود اللاعب على الشاشة
        if (player.HeadLocation.z == 1.0f) continue;
        if (player.HeadLocation.x < -50 || player.HeadLocation.x > screenWidth + 50) continue;
        
        Vec2 playerPos(player.HeadLocation.x, player.HeadLocation.y);
        
        // ===== رسم الصندوق =====
        if (isPlayerBox) {
            float halfBoxWidth = boxWidth / 2.0f;
            float halfBoxHeight = (bottom - top) / 2.0f;
            
            // الزوايا العلوية
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x - halfBoxWidth, top),
                Vec2(playerPos.x - halfBoxWidth + boxWidth/4.0f, top));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x + halfBoxWidth - boxWidth/4.0f, top),
                Vec2(playerPos.x + halfBoxWidth, top));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x - halfBoxWidth, top),
                Vec2(playerPos.x - halfBoxWidth, top + (bottom-top)/4.0f));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x + halfBoxWidth, top),
                Vec2(playerPos.x + halfBoxWidth, top + (bottom-top)/4.0f));
            
            // الزوايا السفلية
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x - halfBoxWidth, bottom),
                Vec2(playerPos.x - halfBoxWidth + boxWidth/4.0f, bottom));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x + halfBoxWidth - boxWidth/4.0f, bottom),
                Vec2(playerPos.x + halfBoxWidth, bottom));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x - halfBoxWidth, bottom),
                Vec2(playerPos.x - halfBoxWidth, bottom - (bottom-top)/4.0f));
            esp.DrawLine(boxColor, boxLineSize,
                Vec2(playerPos.x + halfBoxWidth, bottom),
                Vec2(playerPos.x + halfBoxWidth, bottom - (bottom-top)/4.0f));
        }
        
        // ===== رسم الصحة =====
        if (isPlayerHealth) {
            float healthPercent = std::max(0.0f, std::min(1.0f, player.Health / 100.0f));
            Color healthColor;
            if (healthPercent > 0.5f) healthColor = Color::Green(255);
            else if (healthPercent > 0.25f) healthColor = Color::Yellow(255);
            else healthColor = Color::Red(255);
            
            float healthWidth = boxWidth * 2.0f;
            float healthHeight = (bottom - top) * healthPercent;
            
            // خلفية
            esp.DrawFilledRect(Color::Black(150),
                Vec2(playerPos.x - healthWidth/2.0f - 5.0f, top),
                Vec2(playerPos.x - healthWidth/2.0f - 2.0f, bottom));
            
            // شريط الصحة
            esp.DrawFilledRect(healthColor,
                Vec2(playerPos.x - healthWidth/2.0f - 4.0f, bottom - healthHeight),
                Vec2(playerPos.x - healthWidth/2.0f - 3.0f, bottom));
        }
        
        // ===== رسم الرأس =====
        if (isPlayerHead) {
            esp.DrawFilledCircle(alertColor,
                Vec2(player.HeadLocation.x, player.HeadLocation.y),
                screenHeight / 12.0f / magicNumber);
        }
        
        // ===== رسم معلومات اللاعب =====
        if (isPlayerName || isPlayerDistance) {
            DrawPlayerInfo(esp, player,
                Vec2(playerPos.x, top - textSize * 0.5f),
                textSize, player.isBot, distance);
        }
        
        // ===== رسم السلاح =====
        if (isPlayerWeapon && player.Weapon.isWeapon) {
            esp.DrawWeapon(Color::White(255), player.Weapon.id,
                player.Weapon.ammo, player.Weapon.ammo,
                Vec2(playerPos.x, bottom + textSize * 0.7f),
                textSize);
        }
        
        // ===== رسم أيقونة السلاح =====
        if (isPlayerWeaponIcon && player.Weapon.isWeapon) {
            esp.DrawWeaponIcon(player.Weapon.id,
                Vec2(playerPos.x - 50.0f, top - textSize * 0.6f));
        }
    }
    
    // ===== عرض عدد اللاعبين =====
    if (!response.InLobby) {
        esp.DrawEnemyCount(Color::White(255), 
            Vec2(0, 0),
            Vec2((float)playerCount, (float)botCount));
    }
    
    // ===== تحديث FPS =====
    FPSLimiter.SetFPS(1000);
    FPSLimiter.AutoFPS();
}

#endif //BETA_ESP_IMPORTANT_HACKS_H