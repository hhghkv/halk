#ifndef BETA_ESP_IMPORTANT_ITEMS_H
#define BETA_ESP_IMPORTANT_ITEMS_H

#include <string>
#include <unordered_map>

// ===== تعريفات الأسلحة =====
struct WeaponInfo {
    const char* name;
    const char* category;
    int damage;
    float range;
};

// ===== دوال الحصول على اسم السلاح =====
inline const char* GetWeaponName(int code) {
    switch (code) {
        // بنادق هجومية (AR)
        case 101001: return "AKM";
        case 101002: return "M16A4";
        case 101003: return "SCAR-L";
        case 101004: return "M416";
        case 101005: return "Groza";
        case 101006: return "AUG A3";
        case 101007: return "QBZ";
        case 101008: return "M762";
        case 101009: return "Mk47 Mutant";
        case 101010: return "G36C";
        case 101100: return "FAMAS";
        
        // رشاشات (LMG)
        case 105001: return "M249";
        case 105002: return "DP-28";
        
        // مسدسات رشاشة (SMG)
        case 102001: return "UZI";
        case 102002: return "UMP45";
        case 102003: return "Vector";
        case 102004: return "Thompson SMG";
        case 102005: return "PP-19 Bizon";
        case 102007: return "Skorpion";
        
        // بنادق قنص (Sniper)
        case 103001: return "Kar98K";
        case 103002: return "M24";
        case 103003: return "AWM";
        case 103004: return "SKS";
        case 103005: return "VSS";
        case 103006: return "Mini14";
        case 103007: return "Mk14";
        case 103008: return "Win94";
        case 103009: return "SLR";
        case 103010: return "QBU";
        case 103011: return "Mosin Nagant";
        case 103100: return "Mk12";
        
        // بنادق شوتغان (Shotgun)
        case 104001: return "S686";
        case 104002: return "S1897";
        case 104003: return "S12K";
        case 104004: return "DP12";
        case 104101: return "M1014";
        case 106006: return "Sawed-off";
        
        // مسدسات (Pistol)
        case 106001: return "P92";
        case 106002: return "P1911";
        case 106003: return "R1895";
        case 106004: return "P18C";
        case 106005: return "R45";
        case 106008: return "Vz61";
        case 106010: return "Desert Eagle";
        
        // أخرى
        case 107001: return "Crossbow";
        case 108001: return "Machete";
        case 108002: return "Crowbar";
        case 108003: return "Sickle";
        case 108004: return "Pan";
        
        default: return "Unknown";
    }
}

// ===== دوال الحصول على اسم الملحق =====
inline const char* GetAttachmentName(int code) {
    switch (code) {
        // كواتم
        case 201001: return "Choke";
        case 201002: return "Compensator (SMG)";
        case 201003: return "Compensator (Snipers)";
        case 201004: return "Flash Hider (SMG)";
        case 201005: return "Flash Hider (Snipers)";
        case 201006: return "Suppressor (SMG)";
        case 201007: return "Suppressor (Snipers)";
        case 201009: return "Compensator (AR)";
        case 201010: return "Flash Hider (AR)";
        case 201011: return "Suppressor (AR)";
        case 201012: return "Duckbill";
        
        // مقابض
        case 202001: return "Angled Foregrip";
        case 202002: return "Vertical Foregrip";
        case 202004: return "Light Grip";
        case 202005: return "Half Grip";
        case 202006: return "Thumb Grip";
        case 202007: return "Laser Sight";
        
        // مناظير
        case 203001: return "Red Dot Sight";
        case 203002: return "Holographic Sight";
        case 203003: return "2x Scope";
        case 203004: return "4x Scope";
        case 203005: return "8x Scope";
        case 203014: return "3x Scope";
        case 203015: return "6x Scope";
        case 203018: return "Canted Sight";
        
        // مخازن
        case 204004: return "Extend Mag (SMG)";
        case 204005: return "QuickD Mag (SMG)";
        case 204006: return "ExtendQ Mag (SMG)";
        case 204007: return "Extend Mag (Snipers)";
        case 204008: return "QuickD Mag (Snipers)";
        case 204009: return "ExtendedQ Mag (Snipers)";
        case 204011: return "ExtendQ Mag (AR)";
        case 204012: return "QuickD Mag (AR)";
        case 204013: return "ExtendQ Mag (AR)";
        
        default: return nullptr;
    }
}

// ===== دوال الحصول على اسم الذخيرة =====
inline const char* GetAmmoName(int code) {
    switch (code) {
        case 301001: return "9mm";
        case 302001: return "7.62mm";
        case 303001: return "5.56mm";
        case 304001: return "12 Gauge";
        case 305001: return "45 ACP";
        case 306001: return "300 Magnum";
        case 307001: return "Bolt";
        default: return nullptr;
    }
}

// ===== دوال الحصول على اسم المستلزمات =====
inline const char* GetItemName(int code) {
    switch (code) {
        // حقائب
        case 501001: return "Backpack (Lv. 1)";
        case 501002: return "Backpack (Lv. 2)";
        case 501006: return "Backpack (Lv. 3)";
        
        // خوذ
        case 502001: return "Helmet (Lv. 1)";
        case 502002: return "Helmet (Lv. 2)";
        case 502003: return "Helmet (Lv. 3)";
        
        // دروع
        case 503001: return "Vest (Lv. 1)";
        case 503002: return "Vest (Lv. 2)";
        case 503003: return "Vest (Lv. 3)";
        
        // علاج
        case 601001: return "Energy Drink";
        case 601002: return "Adrenaline";
        case 601003: return "Painkiller";
        case 601004: return "Bandage";
        case 601005: return "First Aid Kit";
        case 601006: return "Med Kit";
        
        default: return nullptr;
    }
}

// ===== دالة رئيسية للبحث =====
inline bool GetBox(int code, char** name) {
    const char* result = GetWeaponName(code);
    if (result != nullptr && strcmp(result, "Unknown") != 0) {
        *name = const_cast<char*>(result);
        return true;
    }
    
    result = GetAttachmentName(code);
    if (result != nullptr) {
        *name = const_cast<char*>(result);
        return true;
    }
    
    result = GetAmmoName(code);
    if (result != nullptr) {
        *name = const_cast<char*>(result);
        return true;
    }
    
    result = GetItemName(code);
    if (result != nullptr) {
        *name = const_cast<char*>(result);
        return true;
    }
    
    return false;
}

#endif //BETA_ESP_IMPORTANT_ITEMS_H