#define BETA_ESP_IMPORTANT_HACKS_H

#include "socket.h"
#include "Color.h"
#include "items.h"
#include "rLogin/Login.h"
#include "Vector3.hpp"
#include "timer.h"

// ===== الثوابت =====
constexpr float MIN_MAGIC_NUMBER = 0.1f;
constexpr float NEAR_DISTANCE_THRESHOLD = 150.0f; // المسافة القريبة
constexpr float FAR_DISTANCE_THRESHOLD = 300.0f;  // المسافة البعيدة
constexpr float VERY_FAR_DISTANCE_THRESHOLD = 600.0f;

// ===== المتغيرات العامة =====
timer FPSLimiter;
Color enemyColor, edgeColor, boxColor, alertColor, teamColor, distanceColor;
Color healthColor, textColor, grenadeColor, indicatorColor;
float screenWidth, screenHeight, magicNumber, scale, skeletonSize;

// ===== الإعدادات =====
Options options {
    1,          // aimBullet
    -1,         // openState
    -1,         // aimT
    3,          // tracingStatus
    false,      // عرض الأسماء
    false,      // عرض الصناديق
    1,          // 
    false,      // عرض الخط
    200,        // aimingRange
    200,        // touchSize
    700,        // touchX
    19,         // touchY
    19,         // 
    -1,         // 
    false       // 
};

OtherFeature otherFeature {
    false, false, false, false, false, false
};

// ===== الدوال المساعدة =====
Color GetDistanceColor(float distance, int alpha = 255) {
    if (distance < 150.0f)
        return Color::Red(alpha);
    else if (distance < 300.0f)
        return Color::Orange(alpha);
    else if (distance < 600.0f)
        return Color::Yellow(alpha);
    else
        return Color::Green(alpha);
}

bool IsInSafeZone(const Vec2& position, const Vec2& screenSize) {
    return !(position.y < 0 || position.x > screenSize.x || 
             position.y > screenSize.y || position.x < 0);
}

std::string GetPlayerStatus(int state) {
    switch(state) {
        case 520:
        case 544:
        case 656:
        case 521:
        case 528:
        case 3145736:
            return "Aiming";
        default:
            return "";
    }
}

bool IsPlayerInCenter(float playerX, float playerY, float top, float bottom, 
                      float screenWidth, float screenHeight) {
    // التحقق من أن اللاعب في منتصف الشاشة (منطقة 20% من المنتصف)
    float centerX = screenWidth / 2;
    float centerY = screenHeight / 2;
    float marginX = screenWidth * 0.1f;
    float marginY = screenHeight * 0.1f;
    
    return (playerX > centerX - marginX && playerX < centerX + marginX &&
            playerY > centerY - marginY && playerY < centerY + marginY);
}

Vec2 CalculateRadarPosition(const Vec2& location, const Vec2& center, float radius) {
    Vec2 direction = location - center;
    float distance = direction.Length();
    if (distance < 0.001f) return center;
    
    Vec2 normalized = direction / distance;
    float radarDistance = std::min(distance, radius);
    return center + normalized * radarDistance;
}

// ===== دوال الرسم =====
void DrawRadar(ESP& canvas, const Vec2& playerLocation, const Vec2& radarCenter, 
               float radarSize, const Color& color, int teamID, bool showTeamID) {
    // رسم خلفية الرادار
    canvas.DrawFillCircle(Color::Black(35), radarCenter, radarSize + (radarSize / 10), 0.5);
    canvas.DrawCircle(Color::White(255), radarCenter, radarSize + (radarSize / 10), 1);
    
    // رسم موقع اللاعب المحلي
    canvas.DrawFilledRoundRect(Color::White(255), 
                              {radarCenter.x - radarSize / 25, radarCenter.y - radarSize / 25},
                              {radarCenter.x + radarSize / 25, radarCenter.y + radarSize / 25});
    
    // حساب موقع العدو على الرادار
    Vec2 radarPos = CalculateRadarPosition(playerLocation, radarCenter, radarSize);
    
    // رسم العدو
    canvas.DrawFillCircle(Color(color.r, color.g, color.b, 255), 
                         radarPos, radarSize / 10, 0.5);
    
    // عرض Team ID إذا كان مطلوباً
    if (showTeamID) {
        canvas.DrawText(Color::White(255), std::to_string(teamID).c_str(), 
                       radarPos, radarSize / 10);
    }
}

void DrawPlayerSkeleton(ESP& canvas, const PlayerBone& bone, const Color& color, 
                        float skeletonSize, const Color& jointColor) {
    // الرقبة - الصدر
    canvas.DrawLine(color, skeletonSize, 
                   Vec2(bone.neck.x, bone.neck.y),
                   Vec2(bone.cheast.x, bone.cheast.y));
    
    // الصدر - الحوض
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.cheast.x, bone.cheast.y),
                   Vec2(bone.pelvis.x, bone.pelvis.y));
    
    // الكتفين
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.neck.x, bone.neck.y),
                   Vec2(bone.lSh.x, bone.lSh.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.neck.x, bone.neck.y),
                   Vec2(bone.rSh.x, bone.rSh.y));
    
    // الذراع الأيسر
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.lSh.x, bone.lSh.y),
                   Vec2(bone.lElb.x, bone.lElb.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.lElb.x, bone.lElb.y),
                   Vec2(bone.lWr.x, bone.lWr.y));
    canvas.DrawFilledCircle(jointColor,
                           Vec2(bone.lWr.x, bone.lWr.y),
                           skeletonSize * 2);
    
    // الذراع الأيمن
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.rSh.x, bone.rSh.y),
                   Vec2(bone.rElb.x, bone.rElb.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.rElb.x, bone.rElb.y),
                   Vec2(bone.rWr.x, bone.rWr.y));
    canvas.DrawFilledCircle(jointColor,
                           Vec2(bone.rWr.x, bone.rWr.y),
                           skeletonSize * 2);
    
    // الساق الأيسر
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.pelvis.x, bone.pelvis.y),
                   Vec2(bone.lTh.x, bone.lTh.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.lTh.x, bone.lTh.y),
                   Vec2(bone.lKn.x, bone.lKn.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.lKn.x, bone.lKn.y),
                   Vec2(bone.lAn.x, bone.lAn.y));
    canvas.DrawFilledCircle(jointColor,
                           Vec2(bone.lAn.x, bone.lAn.y),
                           skeletonSize * 2);
    
    // الساق الأيمن
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.pelvis.x, bone.pelvis.y),
                   Vec2(bone.rTh.x, bone.rTh.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.rTh.x, bone.rTh.y),
                   Vec2(bone.rKn.x, bone.rKn.y));
    canvas.DrawLine(color, skeletonSize,
                   Vec2(bone.rKn.x, bone.rKn.y),
                   Vec2(bone.rAn.x, bone.rAn.y));
    canvas.DrawFilledCircle(jointColor,
                           Vec2(bone.rAn.x, bone.rAn.y),
                           skeletonSize * 2);
}

void DrawPlayerBox(ESP& canvas, float centerX, float top, float bottom, 
                   float boxWidth, float boxHeight, const Color& color, float lineSize) {
    float halfWidth = boxWidth / 2;
    float halfHeight = boxHeight / 2;
    
    // الزوايا العلوية
    canvas.DrawLine(color, lineSize, Vec2(centerX - halfWidth, top), Vec2(centerX - halfWidth + boxWidth/4, top));
    canvas.DrawLine(color, lineSize, Vec2(centerX + halfWidth - boxWidth/4, top), Vec2(centerX + halfWidth, top));
    canvas.DrawLine(color, lineSize, Vec2(centerX - halfWidth, top), Vec2(centerX - halfWidth, top + boxHeight/4));
    canvas.DrawLine(color, lineSize, Vec2(centerX + halfWidth, top), Vec2(centerX + halfWidth, top + boxHeight/4));
    
    // الزوايا السفلية
    canvas.DrawLine(color, lineSize, Vec2(centerX - halfWidth, bottom), Vec2(centerX - halfWidth + boxWidth/4, bottom));
    canvas.DrawLine(color, lineSize, Vec2(centerX + halfWidth - boxWidth/4, bottom), Vec2(centerX + halfWidth, bottom));
    canvas.DrawLine(color, lineSize, Vec2(centerX - halfWidth, bottom), Vec2(centerX - halfWidth, bottom - boxHeight/4));
    canvas.DrawLine(color, lineSize, Vec2(centerX + halfWidth, bottom), Vec2(centerX + halfWidth, bottom - boxHeight/4));
}

void DrawPlayerHealth(ESP& canvas, const Vec2& position, float width, float height, float health) {
    float healthPercent = health / 100.0f;
    Color healthColor = (healthPercent > 0.5f) ? Color::Green(255) : 
                       (healthPercent > 0.25f ? Color::Yellow(255) : Color::Red(255));
    
    // خلفية
    canvas.DrawFilledRect(Color::Black(150), 
                         Vec2(position.x - width/2 - 5, position.y - height/2),
                         Vec2(position.x - width/2 - 2, position.y + height/2));
    
    // الشريط
    float healthHeight = height * healthPercent;
    canvas.DrawFilledRect(healthColor,
                         Vec2(position.x - width/2 - 4, position.y + height/2 - healthHeight),
                         Vec2(position.x - width/2 - 3, position.y + height/2));
}

void DrawGrenadeWarning(ESP& canvas, const GrenadeData& grenade, float textSize) {
    const char* grenadeTypeText;
    Color grenadeColor;
    
    switch(grenade.type) {
        case 1: // قنبلة
            grenadeColor = Color::Red(255);
            grenadeTypeText = "قنبله";
            break;
        case 2: // حارقة
            grenadeColor = Color::Orange(255);
            grenadeTypeText = "حارقه";
            break;
        case 3: // صوتية
            grenadeColor = Color::Yellow(255);
            grenadeTypeText = "صوتيه";
            break;
        default: // دخانية
            grenadeColor = Color::White(255);
            grenadeTypeText = "دخانيه";
    }
    
    char textBuffer[100];
    sprintf(textBuffer, "%s (%.0f m)", grenadeTypeText, grenade.Distance);
    
    canvas.DrawText(grenadeColor, textBuffer, 
                   Vec2(grenade.Location.x, grenade.Location.y + textSize * 1.5f), 
                   textSize);
    canvas.DrawText(grenadeColor, "〇", 
                   Vec2(grenade.Location.x, grenade.Location.y), 
                   textSize);
}

void DrawPlayerInfo(ESP& canvas, const PlayerData& player, const Vec2& position, 
                    float textSize, bool isBot, float distance) {
    // خلفية الاسم
    canvas.DrawFilledName(Color(0, 0, 0, 100),
                         Vec2(position.x - 40, position.y - textSize - 5),
                         Vec2(position.x + 40, position.y + 5));
    
    // عرض الاسم
    if (isBot) {
        canvas.DrawText(Color::White(255), "البوت", 
                       Vec2(position.x, position.y - textSize/2), 
                       textSize * 0.8f);
    } else {
        std::string playerName(reinterpret_cast<const char*>(player.PlayerNameByte), 15);
        canvas.DrawName(Color::White(255), playerName.c_str(),
                       Vec2(position.x, position.y - textSize/2),
                       textSize * 0.8f);
    }
    
    // عرض رقم الفريق
    canvas.DrawTeamID(Color::White(255), player.TeamID,
                     Vec2(position.x - 30, position.y - textSize/2),
                     textSize * 0.6f);
    
    // عرض المسافة
    char distanceText[20];
    sprintf(distanceText, "%.0f", distance);
    canvas.DrawText(Color::White(255), distanceText,
                   Vec2(position.x + 30, position.y - textSize/2),
                   textSize * 0.6f);
}

// ===== الدالة الرئيسية =====
void DrawESP(ESP& esp, int screenWidth, int screenHeight) {
    // إعدادات التهيئة
    Request request;
    Response response;
    request.radarPos = {screenWidth / 4.0f, screenHeight / 4.0f};
    request.radarSize = 150.0f;
    request.ScreenHeight = screenHeight;
    request.ScreenWidth = screenWidth;
    request.options = options;
    request.otherFeature = otherFeature;
    request.Mode = InitMode;
    
    // إرسال واستقبال البيانات
    memset(&response, 0, sizeof(response));
    send((void*)&request, sizeof(request));
    receive((void*)&response);
    
    if (!response.Success) return;
    
    // إعداد المتغيرات
    float scaleY = screenHeight / 1080.0f;
    scale = screenHeight / 1080.0f;
    skeletonSize = scale * 1.5f;
    float boxLineSize = scaleY * 2.0f;
    float textSize = screenHeight / 50.0f;
    Vec2 screenSize(screenWidth, screenHeight);
    
    int botCount = 0, playerCount = 0;
    float fov = response.fov > 0 ? response.fov : 1.0f;
    
    // ===== رسم الرادار =====
    DrawRadar(esp, request.radarPos, request.radarPos, request.radarSize, 
             Color::White(255), 0, false);
    
    // ===== معالجة اللاعبين =====
    for (int i = 0; i < response.PlayerCount; i++) {
        PlayerData& player = response.Players[i];
        
        // حساب المتغيرات الأساسية
        float distance = player.Distance;
        float magicNumber = std::max(distance * fov, MIN_MAGIC_NUMBER);
        float boxWidth = (screenWidth / 6.0f) / magicNumber;
        float halfBoxWidth = boxWidth / 2.0f;
        float verticalOffset = (screenWidth / 1.38f) / magicNumber;
        float top = player.HeadLocation.y - verticalOffset + (screenWidth / 1.7f) / magicNumber;
        float bottom = player.Bone.lAn.y + verticalOffset - (screenWidth / 1.7f) / magicNumber;
        
        // تحديد الألوان
        Color distanceColor = GetDistanceColor(distance);
        Color teamColor = _clrID(player.TeamID, 150);
        Color alertColor = _clrID(player.TeamID, 80);
        Color boxColor = _clrID(player.TeamID, 200);
        
        if (player.isBot) {
            botCount++;
            boxColor = Color::White(255);
            distanceColor = Color::White(255);
        } else {
            playerCount++;
        }
        
        // التحقق من وجود اللاعب في منتصف الشاشة
        bool inCenter = IsPlayerInCenter(player.HeadLocation.x, player.HeadLocation.y,
                                        top, bottom, screenWidth, screenHeight);
        if (inCenter) {
            boxColor = Color::Green(255);
            distanceColor = Color::Green(255);
        }
        
        // رسم الرادار لكل لاعب
        DrawRadar(esp, player.RadarLocation, request.radarPos, request.radarSize, 
                 teamColor, player.TeamID, false);
        
        // التحقق من وجود اللاعب على الشاشة
        if (player.HeadLocation.z == 1.0f) continue;
        if (player.HeadLocation.x < -50 || player.HeadLocation.x > screenWidth + 50) continue;
        
        Vec2 playerPos(player.HeadLocation.x, player.HeadLocation.y);
        
        // ===== رسم الهيكل العظمي =====
        if (isSkeleton && player.Bone.isBone) {
            DrawPlayerSkeleton(esp, player.Bone, boxColor, skeletonSize, 
                              inCenter ? Color::White(255) : Color::Green(255));
        }
        
        // ===== رسم الصندوق =====
        if (isPlayerBox) {
            DrawPlayerBox(esp, playerPos.x, top, bottom, boxWidth, 
                         boxWidth * 1.5f, boxColor, boxLineSize);
        }
        
        // ===== رسم الصحة =====
        if (isPlayerHealth) {
            DrawPlayerHealth(esp, Vec2(playerPos.x, (top + bottom) / 2), 
                            boxWidth * 2, bottom - top, player.Health);
        }
        
        // ===== رسم الرأس =====
        if (isPlayerHead) {
            esp.DrawFilledCircle(alertColor, 
                                Vec2(player.HeadLocation.x, player.HeadLocation.y),
                                screenHeight / 12.0f / magicNumber);
        }
        
        // ===== رسم معلومات اللاعب =====
        if (isPlayerName || isPlayerDistance || isPlayerWeapon) {
            // معلومات قريبة
            if (distance < NEAR_DISTANCE_THRESHOLD) {
                if (isPlayerName) {
                    DrawPlayerInfo(esp, player, 
                                  Vec2(playerPos.x, top - textSize * 0.5f),
                                  textSize, player.isBot, distance);
                }
                
                if (isPlayerDistance) {
                    char distText[20];
                    sprintf(distText, "%.0f M", distance);
                    esp.DrawText(Color(247, 175, 63, 255), distText,
                                Vec2(playerPos.x, bottom + textSize * 0.8f),
                                textSize);
                }
            } 
            // معلومات بعيدة
            else {
                DrawPlayerInfo(esp, player,
                              Vec2(playerPos.x, top - textSize * 0.5f),
                              textSize, player.isBot, distance);
                
                if (isPlayerWeapon && player.Weapon.isWeapon) {
                    esp.DrawWeapon(Color::White(255), player.Weapon.id,
                                  player.Weapon.ammo, player.Weapon.ammo,
                                  Vec2(playerPos.x, bottom + textSize * 0.7f),
                                  textSize);
                }
                
                if (isPlayerWeaponIcon && player.Weapon.isWeapon) {
                    esp.DrawWeaponIcon(player.Weapon.id,
                                      Vec2(playerPos.x - 50, top - textSize * 0.6f));
                }
            }
        }
        
        // ===== المعلومات الإضافية =====
        if (isNation && !player.isBot) {
            esp.DrawNation(Color::White(255), player.PlayerNation,
                          Vec2(playerPos.x, top - textSize * 2.0f),
                          textSize);
        }
        
        if (isPlayerUID && !player.isBot) {
            esp.DrawUserID(Color::White(255), player.PlayerUID,
                          Vec2(playerPos.x - 40, top - textSize * 3.0f),
                          textSize);
        }
        
        // ===== تنبيه 360 درجة =====
        if (is360Alertv2) {
            // خارج الشاشة تماماً
            if (player.HeadLocation.z == 1.0f) {
                Vec2 alertPos = playerPos;
                if (alertPos.x > screenWidth - screenWidth/12) 
                    alertPos.x = screenWidth - screenWidth/120;
                else if (alertPos.x < screenWidth/120) 
                    alertPos.x = screenWidth/12;
                
                if (alertPos.y < screenHeight/1) {
                    esp.DrawFilledCircle(alertColor,
                                        Vec2(screenWidth - alertPos.x, screenHeight - screenHeight/20),
                                        screenHeight/20);
                } else {
                    esp.DrawFilledCircle(alertColor,
                                        Vec2(screenWidth - alertPos.x, screenHeight/20),
                                        screenHeight/20);
                }
            }
        }
    }
    
    // ===== معالجة القنابل =====
    if (isGrenadeWarning) {
        for (int i = 0; i < response.GrenadeCount; i++) {
            if (response.Grenade[i].Location.z != 1.0f) {
                DrawGrenadeWarning(esp, response.Grenade[i], textSize);
            }
        }
    }
    
    // ===== معالجة المركبات والعناصر =====
    if (!isHideItem) {
        // المركبات
        for (int i = 0; i < response.VehicleCount; i++) {
            VehicleData& vehicle = response.Vehicles[i];
            if (vehicle.Location.z != 1.0f) {
                esp.DrawVehicles(vehicle.VehicleName, vehicle.Distance, 
                                vehicle.Health, vehicle.Fuel,
                                Vec2(vehicle.Location.x, vehicle.Location.y),
                                screenHeight / 47.0f);
            }
        }
        
        // العناصر
        for (int i = 0; i < response.ItemsCount; i++) {
            ItemData& item = response.Items[i];
            if (item.Location.z != 1.0f) {
                esp.DrawItems(item.ItemName, item.Distance,
                             Vec2(item.Location.x, item.Location.y),
                             screenHeight / 50.0f);
            }
        }
    }
    
    // ===== عرض عدد اللاعبين =====
    if (!response.InLobby) {
        esp.DrawEnemyCount(Color::White(255), 
                          Vec2(0, 0),
                          Vec2((float)playerCount, (float)botCount));
    }
    
    // ===== عرض وضع التتبع =====
    if (options.tracingStatus) {
        float centerX = screenWidth / 2;
        float centerY = screenHeight / 2;
        esp.DrawFilledRect(Color::Green(50),
                          Vec2(options.touchY - options.touchSize/2, 
                               centerY * 2 - options.touchX + options.touchSize/2),
                          Vec2(options.touchY + options.touchSize/2,
                               centerY * 2 - options.touchX - options.touchSize/2));
    }
    
    // ===== عرض دائرة الهدف =====
    if (options.openState == 0 || options.aimBullet == 0 || options.aimT == 0) {
        Color textColor = (options.openState == 0) ? Color::Red(255) :
                         (options.aimT == 0 ? Color::Blue(255) : Color::Green(255));
        esp.DrawCircle(textColor,
                      Vec2(screenWidth / 2, screenHeight / 2),
                      options.aimingRange, 1.5f);
    }
    
    // ===== تحديث FPS =====
    FPSLimiter.SetFps(1000);
    FPSLimiter.AotuFPS();
}