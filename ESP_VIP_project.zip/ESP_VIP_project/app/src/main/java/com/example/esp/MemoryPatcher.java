package com.example.esp;

/** Safe demo patcher: intentionally performs no writes to other processes. */
public final class MemoryPatcher {
    private MemoryPatcher() {}
    public static boolean applyAll() { return false; }
    public static boolean isSupported() { return false; }
}
