package com.example.esp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

/** Settings screen for the standalone demo UI. */
public class SettingsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        Button overlay = findViewById(R.id.btn_overlay_permission);
        if (overlay != null) {
            overlay.setOnClickListener(v -> {
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                }
            });
        }

        Switch esp = findViewById(R.id.switch_esp);
        if (esp != null) {
            esp.setOnCheckedChangeListener((buttonView, checked) -> {
                Intent i = new Intent(this, ESPOverlayService.class);
                if (checked) {
                    if (BuildCompat.canDrawOverlays(this)) startService(i);
                    else {
                        buttonView.setChecked(false);
                        Toast.makeText(this, "Allow overlay permission first", Toast.LENGTH_SHORT).show();
                    }
                } else stopService(i);
            });
        }
    }

    public void closeSettings(View view) { finish(); }

    private static final class BuildCompat {
        static boolean canDrawOverlays(Activity a) {
            return android.os.Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(a);
        }
    }
}
