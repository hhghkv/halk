namespace esp_demo {
// Safe demo placeholder. No process hooks are installed.
void InitializeHooks() {}
}
