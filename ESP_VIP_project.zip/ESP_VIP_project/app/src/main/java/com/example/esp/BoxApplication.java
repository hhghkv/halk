package com.example.esp;

import android.app.Application;

public class BoxApplication extends Application {

    private static BoxApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    public static BoxApplication get() {
        return instance;
    }
}
