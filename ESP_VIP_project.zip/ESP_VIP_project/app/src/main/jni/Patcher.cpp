#include <cstddef>

namespace esp_demo {
// Safe demo placeholder: no cross-process patching is implemented here.
bool ApplyDemoPatch() { return false; }
}
